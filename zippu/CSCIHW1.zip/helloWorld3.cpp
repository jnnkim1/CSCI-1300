#include <iostream>

using namespace std;

int main() {

    cout << "Hello, world! Hello CSCI 1300" << endl;

}